<?php
$pages = array(
    'witam'=>'Aplikacja w PHP',
    'sqlcmd'=>'SQL',
    'formularz'=>'Formularz'
);
function get_menu($id) {
    global $pages;
    foreach ($pages as $klucz => $wartosc) {
    echo '
    <li calss="nav-item">
        <a class="nav-link js-scroll-tringger" href="?id='.$klucz.'">'.$wartosc.'</a>
    </li>';
    }
}
?>
