# kl2ag2-php
Aplikacja PHP

Do działania aplikacji w katalogu root serwera musi zostać utworzony folder "sesje",
któremu nadać należy pełne uprawnienia (777).
